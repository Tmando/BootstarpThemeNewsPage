<?php get_header(); ?>
      <div class="row sideRow">
      <div class="col-sm-9 contentStyle">
      <?php if ( have_posts() ) : while ( have_posts() ) : the_post();
        echo "<div class=\"row postRow\">";


            if(has_post_thumbnail()):
              echo "<div class=\"col-sm-4\">";
              echo "<img class=\"img-responsive\" src=\"" . get_the_post_thumbnail_url() ."\">";
              echo "</div>";
            endif;



            echo "<div class=\"col-sm-8\">";

              echo "<div class=\"row\">";
                echo "<div class=\"col-sm-12 dateForm\">";
                  echo get_the_date();
                echo "</div>";
              echo "</div>";

              echo "<div class=\"row\">";
                echo "<div class=\"col-sm-12 headerStyle\">";
                  echo the_title();
                echo "</div>";
              echo "</div>";

              echo "<div class=\"row\">";
                echo "<div class=\"col-sm-12 textStyleSingle\">";
                  echo the_content();
                echo "</div>";
              echo "</div>";

            echo "</div>";



        echo "</div>";




    endwhile; endif; ?>
    </div>
    <div class="col-sm-3 sideBar">
    <?php get_sidebar(); ?>
    </div>
  </div>

<?php get_footer(); ?>
