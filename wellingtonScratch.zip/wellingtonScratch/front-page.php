<?php get_header(); ?>
<section class="showcase">

     <div class="container">

       <h1>CodeFactory WordPress Theme</h1>

       <p>Nulla facilisis orci risus, id pharetra urna porta at. Pellentesque erat urna, varius ut mollis quis, ultricies et ante.</p>

       <a class="btn btn-primary btn-lg">Read More</a>

     </div>

   </section>


   <section class="boxes">

     <div class="container">

       <div class="row">

         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-paper-plane" aria-hidden="true"></i>

             <h3>Lorem Ipsum Dolor</h3>

             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at. </p>

           </div>

         </div>


         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-comments" aria-hidden="true"></i>

             <h3>Lorem Ipsum Dolor</h3>

             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>

           </div>

         </div>


         <div class="col-md-4">

           <div class="box">

             <i class="fa fa-power-off" aria-hidden="true"></i>

             <h3>Lorem Ipsum Dolor</h3>

             <p>Vestibulum ac leo ut velit condimentum lacinia sed sed ex. Pellentesque sapien leo, dictum at condimentum at.</p>

           </div>

         </div>

       </div>

     </div>

   </section>




<?php get_footer(); ?>
