<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php
    echo Get_template_directory_uri() . "/style.css" ?>">
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <meta charset="utf-8">
	 <meta http-equiv="X-UA-Compatible" content="IE=edge">
	 <meta name="viewport" content="width=device-width, initial-scale=1">
	 <meta name="description" content="">
	  <meta name="author" content="">
    <?php wp_head();?>
  </head>
  <body>
    <div id="containerOne" class="container-fluid"> <!-- Open Container One  -->
      <?php
    	 $curUrl = get_template_directory_uri() . "/img/1280px-London_12_2012_London_Eye_Panorama_4984.JPG";
       echo "<div style=\" height:60vh; background-size: cover; background-image:url(".$curUrl.") \"id=\"containerTwo\" class=\"row\">"; // Open Container Two
      ?>
        <div id="containerThree" class="col-sm-12"><h1 class="text-center"><?php echo get_bloginfo(); ?></h1> <!-- Open Container Three  -->
        </div> <!-- Close Container Three  -->
      </div> <!-- Open Container Two  -->
      <nav id="bar"class="navbar navbar-default">
          <div class="container-fluid">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <?php

           wp_nav_menu( array(

               'menu'              => 'primary',

               'theme_location'    => 'primary',

               'depth'             => 2,

               'container'         => 'div',

               'container_class'   => 'collapse navbar-collapse',

               'container_id'      => 'bs-example-navbar-collapse-1',

               'menu_class'        => 'nav navbar-nav',

               'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',

               'walker'            => new WP_Bootstrap_Navwalker())

           );

              ?>
              </ul>
            </div><!--/.nav-collapse -->
          </div><!--/.container-fluid -->
        </nav>
