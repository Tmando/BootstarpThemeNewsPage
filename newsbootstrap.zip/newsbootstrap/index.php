<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package NewsBootStrap
 */

get_header(); ?>

	<!-- <div id="primary" class="content-area"> -->
		<!-- <main id="main" class="site-main"> -->

		<?php
		echo "<div class=\"row mainRow\">";
		echo "<div class=\"col-sm-9\">";
		echo "<div class=\"row sideRow\">";
		if ( have_posts() ) :

			if ( is_home() && ! is_front_page() ) : ?>
				<header>
					<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
				</header>

			<?php
			endif;

			/* Start the Loop */
			while ( have_posts() ) : the_post();
				echo "<div class=\"col-sm-3\">";
				if(has_post_thumbnail()) :
					echo "<div class=\"row\">";
					echo "<div class=\"col-sm-12\">";
					echo "<span class=\"img-responsive\">";
					the_post_thumbnail();
					echo "</span>";
					echo "</div>";
					echo "</div>";
				endif;
				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				 echo "<div class=\"row\">";
				 echo "<div class=\"col-sm-12\">"; // col Text
				 echo "<h1 style=\"font-size:15pt !important;
				 color:DarkRed !important;
				 font-family: 'Passion One', cursive !important \">";
				 the_title();
				 echo "</h1>";
				 echo "</div>";
				 echo "</div>";
				 echo "<div class=\"row\">"; // row Text
				 echo "<div class=\"col-sm-12 excerptText\">"; // col Text
				 the_excerpt();
				 echo "</div>"; // close Col Text
				 echo "</div>"; // close Row Text
				 echo "<a href=\"". get_permalink() ."\">more...</a>";



				echo "</div>";  // close col-sm-3
			endwhile;
			echo "</div>";
			echo "</div>";// close col-sm-8

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif; ?>

		<!-- </main> #main -->
	<!-- </div> #primary -->

<?php
get_sidebar();
echo "</div>"; // close sm-row
get_footer();
